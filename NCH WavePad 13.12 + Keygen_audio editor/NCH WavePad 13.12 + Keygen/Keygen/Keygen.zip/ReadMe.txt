================================================================================
           ___         _ ___  ____  ___ _    ___  ___ ___                       
          | _ \__ _ __| (_) \/ /\ \/ / / |  | _ \/ __| __|                      
          |   / _` / _` | |>  <  >  <| | |  |   / (__| _|                       
          |_|_\__,_\__,_|_/_/\_\/_/\_\_|_|  |_|_\\___|___|  [ 2021 ]            
                                                                                
=====================| https://radixx11rce3.blogspot.com |======================
                                                                                
____________                                                                    
RELEASE INFO                                                                    
������������                                                                    
. Name......: NCH Software Keygen                                               
. Date......: 2021-10-02                                                        
. Version...: 1.9                                                               
. File......: Keygen.exe                                                        
. MD5.......: 70BE645013BB40472981B510FEF40341                                  
. SHA1......: 9DC8263E05CC334D6A02A5E0A775CE4C363BD820                          
                                                                                
___________                                                                     
TARGET INFO                                                                     
�����������                                                                     
. Category..: Misc. Tools                                                       
. Protection: Serial/Custom                                                     
. OS........: WinALL                                                            
. Homepage..: http://www.nchsoftware.com - http://www.nch.com.au                
                                                                                
__________                                                                      
HOW TO USE                                                                      
����������                                                                      
1. Disconnect from Internet. Click "Patch Hosts" to block license validation or 
use a firewall to block any outgoing connection to: secure.nch.com.au           
                                                                                
2. Select the target product. Some products will require extra information:     
"Name"/"User Name" and "Location"/"User E-Mail". You must complete these fields 
before generate an ID-Key. The rest of the products doesn't require any user    
information, but you can especify (OPTIONAL) a "Licensed User" name, that will  
be shown in the "About ..." dialog box and in the title bar of each product:    
enter the desired name and click "Save" to write the name to the registry.      
                                                                                
3. Click "Generate". Use "Copy" to copy the full ID-Key or right click over the 
fields to copy each part separately.                                            
                                                                                
4. Use the generated ID-Key to register the program.                            
                                                                                
_____________________                                                           
IMPORTANT (MUST READ)                                                           
���������������������                                                           
- This keygen supports ENGLISH products releases ONLY. Products in other        
languages have differences in license key algorithm parameters.                 
                                                                                
- If you have 2 options for registration: "Register New User..." and "Register  
Site License...", ALWAYS USE THE LAST ONE.                                      
                                                                                
- After registration, if you can't see "Licensed software"/"Licensed User" or   
something like that in the title bar and/or "About" window, RESTART THE PROGRAM 
(don't forget to check the system tray).                                        
                                                                                
- With some products, the "Register software..." and "Purchase online" options  
still available after register them. Just ignore it, it's perfectly normal.     
                                                                                
______________                                                                  
NEWS & UPDATES                                                                  
��������������                                                                  
In almost all my releases you will find an "Options" menu. This menu can be     
opened by cliking the little button with a down-arrow icon (upper-right corner  
of the main window) or with a "stack" icon (lower-right corner of the main      
window), depending on the release. This menu has two useful options:            
                                                                                
. News & Announcements: This option allows to check for the latest news         
  regarding to my site or any other important announcement.                     
                                                                                
. Check for Updates: This option allows to verify if there is a new version of  
  this release, check its changelog and download the new version directly.      
  Almost at the same time you will find the new version also posted on my site. 
                                                                                
NOTE: These options require an Internet connection in order to work. In case    
you have a firewall, probably you will need to make an exception.               
                                                                                
___________________________                                                     
ANTIVIRUS & FALSE POSITIVES                                                     
���������������������������                                                     
Some antivirus can detect this release as a threat and try to remove it. The    
reason for this is because my releases are packed/protected in order to reduce  
its size and avoid alterations to the code. This protection can be erroneously  
identified as a threat, it is what is commonly known as a FALSE POSITIVE. Just  
ignore it, it is safe to use.                                                   
                                                                                
IMPORTANT: there will be no risk when using my releases as long as you have     
downloaded it from the links posted on my site or from the "Check for Updates"  
option. If you have downloaded this release from another site, I CANNOT         
GUARANTEE ITS INTEGRITY. In such case, I will not take responsability for       
eventual problems that arise when using it. Be careful!                         
                                                                                
As a precaution, always check the release hashes.                               
                                                                                
__________                                                                      
DISCLAIMER                                                                      
����������                                                                      
This release is provided AS IS for FOR EVALUATION PURPOSES ONLY! If you can     
afford the software, please BUY IT. Support the developer to make a better      
product.                                                                        
